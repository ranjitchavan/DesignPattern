package com.nabla.commandAPI;

import com.nabla.remoteAPI.Remote;

public class DownCommand implements Command {
	private Remote remoteRef;
	
	
	public DownCommand(Remote remoteRef) {
		super();
		this.remoteRef = remoteRef;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		remoteRef.down();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
