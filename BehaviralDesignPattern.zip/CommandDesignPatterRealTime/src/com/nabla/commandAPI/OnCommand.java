package com.nabla.commandAPI;

import com.nabla.remoteAPI.Remote;

public class OnCommand implements Command {
	private Remote remoteRef;
	
	public OnCommand(Remote remoteRef) {
		super();
		this.remoteRef = remoteRef;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		remoteRef.on();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
