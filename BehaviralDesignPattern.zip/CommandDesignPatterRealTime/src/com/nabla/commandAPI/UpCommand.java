package com.nabla.commandAPI;
import com.nabla.remoteAPI.*;
public class UpCommand implements Command {
	private Remote remoteRef;
	
	
	public UpCommand(Remote remoteRef) {
		super();
		this.remoteRef = remoteRef;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		remoteRef.up();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
