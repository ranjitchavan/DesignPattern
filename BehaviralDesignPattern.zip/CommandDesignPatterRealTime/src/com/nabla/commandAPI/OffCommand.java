package com.nabla.commandAPI;

import com.nabla.remoteAPI.Remote;

public class OffCommand implements Command {
	private Remote remoteRef;
	
	public OffCommand(Remote remoteRef) {
		super();
		this.remoteRef = remoteRef;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		remoteRef.off();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
