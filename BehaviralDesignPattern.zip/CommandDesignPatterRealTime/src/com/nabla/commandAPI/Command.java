package com.nabla.commandAPI;

public interface Command {
	public void execute();
	public void unexecute();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
}
