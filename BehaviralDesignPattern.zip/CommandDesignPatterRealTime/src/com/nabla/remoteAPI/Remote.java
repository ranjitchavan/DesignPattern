package com.nabla.remoteAPI;

public interface Remote {
	public void on();
	public void off();
	public void up();
	public void down();
	
}
