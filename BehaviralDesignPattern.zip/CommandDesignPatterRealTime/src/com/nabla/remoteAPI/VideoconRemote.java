package com.nabla.remoteAPI;

public class VideoconRemote implements Remote {

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Manufacture :"+getClass().getName()+" CMD :ON");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("Manufacture :"+getClass().getName()+" CMD :OFF");
	}

	@Override
	public void up() {
		// TODO Auto-generated method stub
		System.out.println("Manufacture :"+getClass().getName()+" CMD :UP");
	}

	@Override
	public void down() {
		// TODO Auto-generated method stub
		System.out.println("Manufacture :"+getClass().getName()+" CMD :DOWN");
	}

}
