package com.nabla.invoker;

import com.nabla.commandAPI.Command;

public class Invoker {
		public void setCommand(Command c) {
			c.execute();
		}
}
