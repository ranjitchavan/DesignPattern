import com.nabla.commandAPI.OnCommand;
import com.nabla.invoker.Invoker;
import com.nabla.remoteAPI.DellRemote;

public class App {

	public static void main(String[] args) {
		DellRemote dRemoteObj=new DellRemote();
		OnCommand oCmd=new OnCommand(dRemoteObj);
		
		Invoker i=new Invoker();
		i.setCommand(oCmd);
		

	}

}
