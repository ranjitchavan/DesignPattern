
public class Dispence500Rupess implements DispenseChain {
	private DispenseChain dispence;
	private static final int AMOUNT=500;
	public  void setNext(DispenseChain dispence) {
		// TODO Auto-generated constructor stub
		this.dispence=dispence;  //refernece of next reciver
		
	}
	@Override
	public boolean  dispence(Currency cur) {
		if(cur.getAmount()<AMOUNT) {
			return dispence.dispence(cur);
			
		}else {
			int notes=cur.getAmount()/500;
			money.put("500", notes);  //putting 500rs currency in hashMap
			if(cur.getAmount()%500!=0)
				return dispence.dispence(new Currency(cur.getAmount()%500)); //delegating request to next 
			else
				return true; //transaction successfully completed
		}
		
		
	}

}
