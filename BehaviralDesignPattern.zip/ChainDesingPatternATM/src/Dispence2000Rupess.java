
public class Dispence2000Rupess implements DispenseChain {
    private DispenseChain dispence;

	private static final int AMOUNT=2000;
	
	public  void setNext(DispenseChain dispence) {
		// TODO Auto-generated constructor stub
		this.dispence=dispence;  //refernece of next reciver
		
	}
	
	@Override
	public boolean dispence(Currency cur) {
		
		if(cur.getAmount()<AMOUNT) {
		
			return dispence.dispence(cur);
			
		}else {
			
			int notes=cur.getAmount()/2000;
			money.put("2000", notes); //putting 2000rs currency in hashMap
			if(cur.getAmount()%2000!=0)
				return dispence.dispence(new Currency(cur.getAmount()%2000)); //delegating request to next 
			else
				return true; //transaction successfully completed
		}
		
		
	}

}
