
public class Dispence100Rupess implements DispenseChain {

	private static final int AMOUNT=100;
	
	@Override
	public boolean dispence(Currency cur) {
		// TODO Auto-generated method stub
		if(cur.getAmount()<AMOUNT)
			return false;     //insufficent amount
		else {
			int notes=cur.getAmount()/100;
			money.put("100", notes);  //putting 100rs currency in hashMap
			if(cur.getAmount()%100!=0) 
				return false; //insufficent amount
			else 
				return true;  //transaction successfully completed
			
		}
	}

}
