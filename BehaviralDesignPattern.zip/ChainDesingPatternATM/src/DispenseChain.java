import java.util.HashMap;

public interface DispenseChain {
	HashMap<String,Integer> money=new HashMap<String,Integer>(); //currency saver
	public boolean dispence(Currency cur); //dispeence machine
}
