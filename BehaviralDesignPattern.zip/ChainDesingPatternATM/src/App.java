
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Dispence100Rupess d100=new Dispence100Rupess();
		Dispence200Rupess d200=new Dispence200Rupess();
		Dispence500Rupess d500=new Dispence500Rupess();
		Dispence2000Rupess d2000=new Dispence2000Rupess();
		d2000.setNext(d500);  //injecting next reciver 
		d500.setNext(d200);	  //injecting next reciver 
		d200.setNext(d100);   //injecting next reciver  
		
		if(d2000.dispence(new Currency(25100)))
			System.out.println(DispenseChain.money); //get the Currency
		else 
			System.out.println("Insufficient amount "); //amount not available
			
		
		
	}

}
