
public class Dispence200Rupess implements DispenseChain {
	private DispenseChain dispence;
	
	private static final int AMOUNT=200;
	public  void setNext(DispenseChain dispence) {
		// TODO Auto-generated constructor stub
		this.dispence=dispence;  //refernece of next reciver
		
	}
	@Override
	public boolean dispence(Currency cur) {
		// TODO Auto-generated method stub
		if(cur.getAmount()<AMOUNT) {
			
			
			return dispence.dispence(cur);
			
		}else {
			int notes=cur.getAmount()/200;
			money.put("200", notes); //putting 200rs currency in hashMap
			if(cur.getAmount()%200!=0) 
				return dispence.dispence(new Currency(cur.getAmount()%200)); //delegating request to next 
		
			else
				return true; //transaction successfully completed
			
		}
		
		
	}

}
