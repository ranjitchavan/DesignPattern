
public class CloseCommand implements Command {
	private Notepad notepad;
	
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		notepad.close();
	}

	public CloseCommand(Notepad notepad) {
		super();
		this.notepad = notepad;
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub
		
	}

}
