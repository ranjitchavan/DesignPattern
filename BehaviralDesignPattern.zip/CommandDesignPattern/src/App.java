
public class App {
	public static void main(String a[]) {
		Notepad n=new Notepad();
		Command opN=new OpenCommand(n);
		Command opC=new CloseCommand(n);
		
		
		Invoker i=new Invoker();
		i.setCommand(opN);
		
	}
}
