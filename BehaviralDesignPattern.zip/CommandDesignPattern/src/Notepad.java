
public class Notepad {
	public void open() {
		System.out.println(getClass().getName()+" : CMD:OPEN");
	}
	public void close() {
		System.out.println(getClass().getName()+" : CMD:CLOSE");
	}
	public void save() {
		System.out.println(getClass().getName()+" : CMD:SAVE");
	}
}
