
public class OpenCommand implements Command {
	private Notepad notepad;
	
	public OpenCommand(Notepad notepad) {
		super();
		this.notepad = notepad;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		notepad.open();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
