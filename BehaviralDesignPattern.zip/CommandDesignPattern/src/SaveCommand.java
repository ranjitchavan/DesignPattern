
public class SaveCommand implements Command {
	private Notepad notepad;
	
	public SaveCommand(Notepad notepad) {
		super();
		this.notepad = notepad;
	}

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		notepad.save();
	}

	@Override
	public void unexecute() {
		// TODO Auto-generated method stub

	}

}
