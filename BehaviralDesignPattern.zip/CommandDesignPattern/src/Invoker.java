public class Invoker {
	
	public void setCommand(Command c) {
		c.execute();
	}
}
