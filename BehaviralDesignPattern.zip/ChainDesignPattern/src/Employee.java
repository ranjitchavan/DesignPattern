
public abstract class Employee {
	protected Employee nextSuper;
	
	public void setNextSuperWiser(Employee nextSuper) {
		this.nextSuper=nextSuper;
	}
	
	
	public abstract void applyLeave(String name,int numberOfDaysLeave);
}
