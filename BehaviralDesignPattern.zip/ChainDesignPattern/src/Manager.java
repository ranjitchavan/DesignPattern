
public class Manager extends Employee {
	private static final int MAX_LEAVE_APPROVED=20;
	@Override
	public void applyLeave(String name, int numberOfDaysLeave) {
		if(numberOfDaysLeave<=MAX_LEAVE_APPROVED) {
			approvedLeave(numberOfDaysLeave);
		}else {
			nextSuper.applyLeave(name,numberOfDaysLeave);
		}
	}
	public void approvedLeave( int numberOfDaysLeave) {
		System.out.println(getClass().getName()+" :Your Leave is approved for "+numberOfDaysLeave + "Days");
	
}
}
