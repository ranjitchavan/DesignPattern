
public class HR extends Employee {
	private static final int MAX_LEAVE_APPROVED=30;
	@Override
	public void applyLeave(String name, int numberOfDaysLeave) {
			if(numberOfDaysLeave<=MAX_LEAVE_APPROVED) {
				approvedLeave(numberOfDaysLeave);
			}else {
				System.out.println("your leave is not approved Please contact HR department");
			}
	}
	public void approvedLeave( int numberOfDaysLeave) {
			System.out.println(getClass().getName()+" :Your Leave is approved for "+numberOfDaysLeave + "Days");
		
	}
}
