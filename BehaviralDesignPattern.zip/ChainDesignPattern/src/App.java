
public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HR h=new HR();
		Manager m=new Manager();
		TeamLead t=new TeamLead();
		t.setNextSuperWiser(m);
		m.setNextSuperWiser(h);
		
		t.applyLeave("Ranjit", 15); //MANAGER
		t.applyLeave("Danny", 5);  //TL
		t.applyLeave("Tony", 25); //HR
		t.applyLeave("Jack", 35); //NOT	
	}

}
